namespace AjaxControlToolkit.MaskedEditValidatorCompatibility
{
    using System.Web.UI;

    internal interface IWebControlAccessor {
        HtmlTextWriterTag TagKey {
            get;
        }
    }
}
